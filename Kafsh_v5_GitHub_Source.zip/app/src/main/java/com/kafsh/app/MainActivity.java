package com.kafsh.app;

import android.app.Activity;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;
import com.journeyapps.barcodescanner.IntentIntegrator;
import com.journeyapps.barcodescanner.IntentResult;
import android.content.Intent;

public class MainActivity extends Activity {
    WebView w;
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        w=new WebView(this);
        w.getSettings().setJavaScriptEnabled(true);
        w.getSettings().setDomStorageEnabled(true);
        w.setWebViewClient(new WebViewClient());
        w.setOverScrollMode(View.OVER_SCROLL_NEVER);
        w.addJavascriptInterface(new AppBridge(), "AndroidApp");
        w.loadUrl("file:///android_asset/index.html");
        setContentView(w);
    }
    public void startBarcode(){
        new IntentIntegrator(this).setPrompt("بارکد کالا را مقابل دوربین بگیرید").setBeepEnabled(true).setOrientationLocked(false).initiateScan();
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        IntentResult r=IntentIntegrator.parseActivityResult(requestCode,resultCode,data);
        if(r!=null){ if(r.getContents()!=null){ String s=r.getContents().replace("\\","\\\\").replace("'","\\'"); w.evaluateJavascript("setScannedBarcode('"+s+"')",null); } return; }
        super.onActivityResult(requestCode,resultCode,data);
    }
    public class AppBridge {
        @JavascriptInterface public void scanBarcode(){ startBarcode(); }
        @JavascriptInterface public void printHtml(String html){
            final WebView pv=new WebView(MainActivity.this);
            pv.getSettings().setJavaScriptEnabled(true);
            pv.loadDataWithBaseURL(null,html,"text/html","UTF-8",null);
            pv.setWebViewClient(new WebViewClient(){
                @Override public void onPageFinished(WebView view,String url){
                    PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);
                    pm.print("فاکتور کفش",view,new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build());
                }
            });
        }
    }
    @Override public void onBackPressed(){if(w.canGoBack())w.goBack();else super.onBackPressed();}
}
